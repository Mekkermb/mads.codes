import React from "react";
import { DAL } from "@/server/data-access-layer";
import Project from "@/components/Project";

async function Projects() {
  const { rows } = await DAL.query.getProjects();
  const [visibleSections, setVisibleSections] = React.useState(
    Array(rows.length).fill(false),
  );

  return (
    <div style={{ overflow: "hidden" }}>
      {rows.map((project, index) => (
        <Project
          key={project.id}
          project={project}
          index={index}
          setVisibleSections={setVisibleSections}
        />
      ))}
    </div>
  );
}

export default Projects;
