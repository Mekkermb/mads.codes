export { default } from "./SlideWrapper";
export * from "./SlideWrapper";
