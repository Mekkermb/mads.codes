"use client";
import React from "react";
import { motion } from "framer-motion";
import Image from "next/image";

const Project = ({ project, index, setVisibleSections }) => {
  const projectRef = React.useRef();

  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          setVisibleSections((prev) => {
            const newState = [...prev];
            newState[index] = true;
            return newState;
          });
        }
      },
      { threshold: 0.5 },
    );

    if (projectRef.current) {
      observer.observe(projectRef.current);
    }

    return () => {
      if (projectRef.current) {
        observer.unobserve(projectRef.current);
      }
    };
  }, [index, setVisibleSections]);

  return (
    <motion.div
      ref={projectRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: setVisibleSections[index] ? 1 : 0 }}
      transition={{ duration: 0.5 }}
      style={{ height: "100vh" }}
    >
      <div className="aspect-video w-32">
        <div className="text-white">
          {project.name} {index}
        </div>
        <Image
          src={project.illustration}
          alt={project.description}
          width={2880}
          height={1620}
          className="absolute inset-0 -z-10"
        />
      </div>
    </motion.div>
  );
};

export default Project;
