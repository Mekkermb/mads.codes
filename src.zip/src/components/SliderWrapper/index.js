export * from "./SliderWrapper";
export { default } from "./SliderWrapper";
